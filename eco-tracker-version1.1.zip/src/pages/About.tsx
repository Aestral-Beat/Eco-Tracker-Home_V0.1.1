const About = () => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">About EcoTracker</h2>
      <p>This site helps South African households track and reduce their environmental impact.</p>
    </div>
  );
};

export default About;