type Props = {
  label: string;
  value: string;
};

const TrackerCard = ({ label, value }: Props) => {
  return (
    <div className="bg-white rounded-2xl shadow p-4">
      <h3 className="text-lg font-medium">{label}</h3>
      <p className="text-2xl text-green-700 font-bold">{value}</p>
    </div>
  );
};

export default TrackerCard;