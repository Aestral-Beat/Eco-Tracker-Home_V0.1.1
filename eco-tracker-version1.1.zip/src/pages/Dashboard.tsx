import TrackerCard from "../components/TrackerCard";

const Dashboard = () => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Your Eco Footprint</h2>
      <div className="grid gap-4 md:grid-cols-2">
        <TrackerCard label="Electricity Usage" value="350 kWh" />
        <TrackerCard label="Water Consumption" value="12,000 L" />
        <TrackerCard label="Recycling Rate" value="75%" />
        <TrackerCard label="Carbon Footprint" value="1.2 tons CO₂" />
      </div>
    </div>
  );
};

export default Dashboard;