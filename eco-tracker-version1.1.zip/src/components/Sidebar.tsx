import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <aside className="w-64 bg-white border-r p-4 space-y-4">
      <h1 className="text-2xl font-bold">EcoTracker</h1>
      <nav className="flex flex-col gap-2">
        <Link to="/" className="hover:text-blue-600">Dashboard</Link>
        <Link to="/about" className="hover:text-blue-600">About</Link>
      </nav>
    </aside>
  );
};

export default Sidebar;